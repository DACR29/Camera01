package com.diego.camaradibujo;

import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {

    private static final int MAX_IMAGE_SIDE = 2048;

    private PreviewView previewView;
    private OverlayImageView overlay;
    private TextView hint;
    private LinearLayout panel;
    private Button showPanelButton;
    private Button lockButton, torchButton, grayButton;
    private TextView alphaLabel;

    private Camera camera;
    private boolean torchOn = false;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<String> cameraPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    startCamera();
                } else {
                    Toast.makeText(this, "Se necesita el permiso de cámara", Toast.LENGTH_LONG).show();
                }
            });

    private final ActivityResultLauncher<PickVisualMediaRequest> imagePicker =
            registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), uri -> {
                if (uri != null) loadImage(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(buildUi());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    // ---------------------------------------------------------------- UI

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, match());

        overlay = new OverlayImageView(this);
        overlay.setImageAlpha(128);
        root.addView(overlay, match());

        hint = new TextView(this);
        hint.setText("Toca «Imagen» para elegir una foto de la galería.\n\n"
                + "Pon el teléfono sobre un vaso, apuntando al papel,\n"
                + "y calca la imagen mirando la pantalla.");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        hint.setGravity(Gravity.CENTER);
        hint.setShadowLayer(6f, 0f, 0f, Color.BLACK);
        hint.setPadding(dp(24), 0, dp(24), 0);
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(hint, hintLp);

        // ---- Panel inferior
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xCC000000);
        panel.setPadding(dp(12), dp(8), dp(12), dp(8));

        LinearLayout alphaRow = new LinearLayout(this);
        alphaRow.setOrientation(LinearLayout.HORIZONTAL);
        alphaRow.setGravity(Gravity.CENTER_VERTICAL);

        alphaLabel = new TextView(this);
        alphaLabel.setTextColor(Color.WHITE);
        alphaLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        alphaLabel.setMinWidth(dp(128));
        alphaRow.addView(alphaLabel);

        SeekBar alpha = new SeekBar(this);
        alpha.setMax(100);
        alpha.setProgress(50);
        updateAlphaLabel(50);
        alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                // p = opacidad en %; 0 = invisible, 100 = sólida
                overlay.setImageAlpha(Math.round(p * 2.55f));
                updateAlphaLabel(p);
            }

            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        alphaRow.addView(alpha, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(alphaRow);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(buttons);

        buttons.addView(button("🖼  Imagen", v -> pickImage()));
        lockButton = button("🔓  Bloquear", v -> toggleLock());
        buttons.addView(lockButton);
        buttons.addView(button("↔  Voltear", v -> overlay.flipHorizontal()));
        grayButton = button("◐  B/N", v -> toggleGray());
        buttons.addView(grayButton);
        torchButton = button("🔦  Linterna", v -> toggleTorch());
        buttons.addView(torchButton);
        buttons.addView(button("⟲  Centrar", v -> overlay.fitToView()));
        buttons.addView(button("▼  Ocultar", v -> setPanelVisible(false)));
        panel.addView(scroll);

        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(panel, panelLp);

        // Botón para volver a mostrar el panel
        showPanelButton = button("▲  Controles", v -> setPanelVisible(true));
        showPanelButton.setVisibility(View.GONE);
        FrameLayout.LayoutParams showLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        showLp.setMargins(dp(12), dp(12), dp(12), dp(12));
        root.addView(showPanelButton, showLp);

        // Respetar barras del sistema (edge-to-edge en Android 15+)
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars());
                top = i.top;
                bottom = i.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            panel.setPadding(dp(12), dp(8), dp(12), dp(8) + bottom);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) showPanelButton.getLayoutParams();
            lp.bottomMargin = dp(12) + bottom;
            lp.topMargin = dp(12) + top;
            showPanelButton.setLayoutParams(lp);
            return insets;
        });

        return root;
    }

    private void updateAlphaLabel(int percent) {
        alphaLabel.setText("Opacidad " + percent + "%");
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setPadding(dp(14), dp(6), dp(14), dp(6));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF333344);
        bg.setCornerRadius(dp(20));
        b.setBackground(bg);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        lp.setMargins(dp(4), dp(6), dp(4), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private void setButtonActive(Button b, boolean active) {
        GradientDrawable bg = (GradientDrawable) b.getBackground();
        bg.setColor(active ? 0xFF6D4AFF : 0xFF333344);
    }

    private void setPanelVisible(boolean visible) {
        panel.setVisibility(visible ? View.VISIBLE : View.GONE);
        showPanelButton.setVisibility(visible ? View.GONE : View.VISIBLE);
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- Acciones

    private void pickImage() {
        imagePicker.launch(new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                .build());
    }

    private void toggleLock() {
        boolean locked = !overlay.isLocked();
        overlay.setLocked(locked);
        lockButton.setText(locked ? "🔒  Bloqueada" : "🔓  Bloquear");
        setButtonActive(lockButton, locked);
        Toast.makeText(this, locked ? "Imagen bloqueada: ya puedes dibujar" : "Imagen desbloqueada",
                Toast.LENGTH_SHORT).show();
    }

    private void toggleGray() {
        boolean gray = !overlay.isGrayscale();
        overlay.setGrayscale(gray);
        setButtonActive(grayButton, gray);
    }

    private void toggleTorch() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) {
            Toast.makeText(this, "Este dispositivo no tiene linterna", Toast.LENGTH_SHORT).show();
            return;
        }
        torchOn = !torchOn;
        camera.getCameraControl().enableTorch(torchOn);
        setButtonActive(torchButton, torchOn);
    }

    // ---------------------------------------------------------------- Cámara

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                provider.unbindAll();
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview);
                if (torchOn) camera.getCameraControl().enableTorch(true);
            } catch (Exception e) {
                Toast.makeText(this, "No se pudo abrir la cámara: " + e.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    // ---------------------------------------------------------------- Imagen

    private void loadImage(Uri uri) {
        io.execute(() -> {
            Bitmap bmp = null;
            String error = null;
            try {
                bmp = decode(uri);
            } catch (Throwable t) {
                error = t.getMessage();
            }
            final Bitmap result = bmp;
            final String err = error;
            runOnUiThread(() -> {
                if (result == null) {
                    Toast.makeText(this, "No se pudo abrir la imagen" + (err != null ? ": " + err : ""),
                            Toast.LENGTH_LONG).show();
                    return;
                }
                overlay.setBitmapAndFit(result);
                hint.setVisibility(View.GONE);
            });
        });
    }

    private Bitmap decode(Uri uri) throws Exception {
        ContentResolver cr = getContentResolver();
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.Source src = ImageDecoder.createSource(cr, uri);
            return ImageDecoder.decodeBitmap(src, (decoder, info, source) -> {
                int w = info.getSize().getWidth();
                int h = info.getSize().getHeight();
                int max = Math.max(w, h);
                if (max > MAX_IMAGE_SIDE) {
                    float s = (float) MAX_IMAGE_SIDE / max;
                    decoder.setTargetSize(Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)));
                }
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        }
        // Android 7–8: BitmapFactory con submuestreo
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = cr.openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > MAX_IMAGE_SIDE) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        try (InputStream in = cr.openInputStream(uri)) {
            return BitmapFactory.decodeStream(in, null, opts);
        }
    }
}
