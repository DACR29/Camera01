package com.diego.camaradibujo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.widget.ImageView;

/**
 * Imagen superpuesta sobre la cámara.
 * 1 dedo: mover · 2 dedos: zoom y rotar. Se puede bloquear para dibujar sin moverla.
 */
public class OverlayImageView extends ImageView {

    private static final int NONE = 0, DRAG = 1, ZOOM = 2;

    private final Matrix matrix = new Matrix();
    private int mode = NONE;
    private float lastX, lastY;
    private float lastDist, lastAngle, lastMidX, lastMidY;
    private boolean locked = false;
    private boolean grayscale = false;
    private boolean needsFit = false;

    public OverlayImageView(Context context) {
        super(context);
        setScaleType(ScaleType.MATRIX);
    }

    public void setBitmapAndFit(Bitmap bitmap) {
        setImageBitmap(bitmap);
        needsFit = true;
        if (getWidth() > 0) fitToView();
    }

    public boolean hasImage() {
        return getDrawable() != null;
    }

    /** Centra la imagen y la ajusta al 90% de la pantalla. */
    public void fitToView() {
        Drawable d = getDrawable();
        if (d == null || getWidth() == 0 || getHeight() == 0) return;
        float dw = d.getIntrinsicWidth();
        float dh = d.getIntrinsicHeight();
        if (dw <= 0 || dh <= 0) return;
        float s = Math.min(getWidth() * 0.9f / dw, getHeight() * 0.9f / dh);
        matrix.reset();
        matrix.postScale(s, s);
        matrix.postTranslate((getWidth() - dw * s) / 2f, (getHeight() - dh * s) / 2f);
        setImageMatrix(matrix);
        needsFit = false;
    }

    /** Espejo horizontal respecto al centro de la imagen. */
    public void flipHorizontal() {
        Drawable d = getDrawable();
        if (d == null) return;
        float[] c = {d.getIntrinsicWidth() / 2f, d.getIntrinsicHeight() / 2f};
        matrix.mapPoints(c);
        // Rotación actual de la imagen, para voltear sobre su propio eje
        float[] v = new float[9];
        matrix.getValues(v);
        float angle = (float) Math.toDegrees(Math.atan2(v[Matrix.MSKEW_Y], v[Matrix.MSCALE_X]));
        matrix.postRotate(-angle, c[0], c[1]);
        matrix.postScale(-1f, 1f, c[0], c[1]);
        matrix.postRotate(angle, c[0], c[1]);
        setImageMatrix(matrix);
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
        mode = NONE;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setGrayscale(boolean gray) {
        grayscale = gray;
        if (gray) {
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(0f);
            setColorFilter(new ColorMatrixColorFilter(cm));
        } else {
            clearColorFilter();
        }
    }

    public boolean isGrayscale() {
        return grayscale;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (needsFit) fitToView();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (locked || getDrawable() == null) return false;

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX();
                lastY = e.getY();
                mode = DRAG;
                break;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() >= 2) {
                    lastDist = distance(e);
                    lastAngle = angle(e);
                    lastMidX = (e.getX(0) + e.getX(1)) / 2f;
                    lastMidY = (e.getY(0) + e.getY(1)) / 2f;
                    mode = ZOOM;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                if (mode == DRAG && e.getPointerCount() == 1) {
                    float x = e.getX(), y = e.getY();
                    matrix.postTranslate(x - lastX, y - lastY);
                    lastX = x;
                    lastY = y;
                    setImageMatrix(matrix);
                } else if (mode == ZOOM && e.getPointerCount() >= 2) {
                    float dist = distance(e);
                    float ang = angle(e);
                    float midX = (e.getX(0) + e.getX(1)) / 2f;
                    float midY = (e.getY(0) + e.getY(1)) / 2f;
                    if (lastDist > 10f && dist > 10f) {
                        float scale = dist / lastDist;
                        matrix.postScale(scale, scale, midX, midY);
                    }
                    matrix.postRotate(ang - lastAngle, midX, midY);
                    matrix.postTranslate(midX - lastMidX, midY - lastMidY);
                    lastDist = dist;
                    lastAngle = ang;
                    lastMidX = midX;
                    lastMidY = midY;
                    setImageMatrix(matrix);
                }
                break;

            case MotionEvent.ACTION_POINTER_UP:
                if (e.getPointerCount() == 2) {
                    // Sigue arrastrando con el dedo que queda
                    int remaining = e.getActionIndex() == 0 ? 1 : 0;
                    lastX = e.getX(remaining);
                    lastY = e.getY(remaining);
                    mode = DRAG;
                } else if (e.getPointerCount() > 2) {
                    // Re-calcular referencia con los dedos restantes
                    mode = NONE;
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                mode = NONE;
                break;
        }
        return true;
    }

    private static float distance(MotionEvent e) {
        float dx = e.getX(0) - e.getX(1);
        float dy = e.getY(0) - e.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float angle(MotionEvent e) {
        return (float) Math.toDegrees(Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
    }
}
