# Cámara Dibujo

App Android para calcar dibujos con la cámara: pones el teléfono sobre un vaso
apuntando al papel, eliges una imagen de la galería, la haces transparente y calcas.

## Funciones
- Vista de cámara a pantalla completa (CameraX)
- Imagen de la galería (selector de fotos de Android, sin permiso de almacenamiento)
- Control de opacidad 0–100 %
- Mover (1 dedo), zoom y rotar (2 dedos)
- Bloquear la imagen para dibujar sin moverla
- Voltear (espejo), blanco y negro, linterna, centrar, ocultar controles
- Pantalla siempre encendida

## Compilar el APK

### Opción A – GitHub Actions (sin instalar nada)
1. Crea un repo en GitHub y sube esta carpeta (incluida `.github/`).
2. Pestaña **Actions** → "Compilar APK" se ejecuta sola (~4 min).
3. Descarga el artefacto `CamaraDibujo-apk` → `app-release.apk`.

### Opción B – Local (Linux)
Requisitos: JDK 17+ y Android SDK (cmdline-tools).
```bash
export ANDROID_HOME=$HOME/Android/Sdk
sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"
./gradlew assembleRelease
# APK: app/build/outputs/apk/release/app-release.apk
adb install app/build/outputs/apk/release/app-release.apk
```
En Fedora Silverblue/Kinoite puedes hacerlo dentro de una Distrobox.

### Opción C – Android Studio
File → Open → esta carpeta → Build → Build APK(s).

El APK release está firmado con la clave debug: se instala directo, pero no sirve
para Play Store.
